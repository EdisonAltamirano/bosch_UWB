from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

from .aoa import TrackAoA
from .types import CfarDetection, PreprocessedSession, SpectrogramResult, Track
from .visualization_utils import db_limits, jet_color, magnitude_to_db, power_ratio_to_db


def save_range_time_plot(preprocessed: PreprocessedSession, output_path: Path) -> None:
    frame_axis = preprocessed.session.timestamps_s

    # Crop to bins at or beyond wall_clip_m.  Bins below this threshold were
    # zeroed in preprocessing; including them would show 20*log10(1e-6)≈-120 dB
    # as a solid dark band and collapse the colormap range for the real signal.
    full_range = preprocessed.range_axis_m
    valid = full_range >= preprocessed.config.wall_clip_m
    range_axis = full_range[valid]

    raw = magnitude_to_db(preprocessed.raw_magnitude[:, valid]).T
    clutter = magnitude_to_db(preprocessed.clutter_removed[:, valid]).T
    raw_vmin, raw_vmax = db_limits(raw)
    clutter_vmin, clutter_vmax = db_limits(clutter)

    fig, axes = plt.subplots(2, 1, figsize=(12, 9), sharex=True)

    raw_im = axes[0].imshow(
        raw,
        aspect="auto",
        origin="lower",
        extent=[frame_axis[0], frame_axis[-1], range_axis[0], range_axis[-1]],
        cmap="jet",
        vmin=raw_vmin,
        vmax=raw_vmax,
    )
    axes[0].set_title(f"Raw range-time magnitude (path {preprocessed.selected_path}, dB)")
    axes[0].set_ylabel("Range (m)")
    fig.colorbar(raw_im, ax=axes[0], label="Magnitude (dB)")

    im = axes[1].imshow(
        clutter,
        aspect="auto",
        origin="lower",
        extent=[frame_axis[0], frame_axis[-1], range_axis[0], range_axis[-1]],
        cmap="jet",
        vmin=clutter_vmin,
        vmax=clutter_vmax,
    )
    axes[1].set_title("Clutter-suppressed range-time magnitude (dB)")
    axes[1].set_ylabel("Range (m)")
    axes[1].set_xlabel("Time (s)")
    fig.colorbar(im, ax=axes[1], label="Magnitude (dB)")

    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_peak_tracking_plot(preprocessed: PreprocessedSession, output_path: Path) -> None:
    peak_taps = np.argmax(preprocessed.clutter_removed, axis=1)
    peak_ranges = preprocessed.range_axis_m[peak_taps]

    fig, ax = plt.subplots(figsize=(11, 4))
    ax.plot(preprocessed.session.timestamps_s, peak_ranges, linewidth=1.0, color=jet_color(0, 2))
    ax.set_title("Dominant moving reflector range over time")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Range (m)")
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_presence_score_plot(preprocessed: PreprocessedSession, output_path: Path) -> None:
    timestamps = preprocessed.session.timestamps_s
    scores_db = power_ratio_to_db(preprocessed.roi_to_background_power_ratio)
    threshold_db = float(power_ratio_to_db(np.asarray([preprocessed.presence_threshold], dtype=np.float32))[0])
    states = preprocessed.presence_mask.astype(np.float32)

    fig, axes = plt.subplots(2, 1, figsize=(12, 7), sharex=True, height_ratios=(3, 1))

    axes[0].plot(
        timestamps,
        scores_db,
        color=jet_color(1, 5),
        linewidth=1.4,
        label="ROI/background power ratio (dB)",
    )
    axes[0].axhline(
        threshold_db,
        color=jet_color(4, 5),
        linestyle="--",
        linewidth=1.2,
        label=f"Threshold = {threshold_db:.2f} dB",
    )
    axes[0].fill_between(
        timestamps,
        np.minimum(scores_db, threshold_db),
        scores_db,
        where=preprocessed.presence_mask,
        color=jet_color(2, 5),
        alpha=0.35,
        interpolate=True,
        label="Monitoring state",
    )
    axes[0].set_title("Presence checking to monitoring transition")
    axes[0].set_ylabel("ROI / background power (dB)")
    axes[0].grid(True, alpha=0.25)
    axes[0].legend(loc="upper right")

    axes[1].step(timestamps, states, where="post", color=jet_color(3, 5), linewidth=1.6)
    axes[1].fill_between(timestamps, 0.0, states, step="post", color=jet_color(3, 5), alpha=0.25)
    axes[1].set_yticks([0.0, 1.0], labels=["checking", "monitoring"])
    axes[1].set_ylim(-0.1, 1.1)
    axes[1].set_xlabel("Time (s)")
    axes[1].set_ylabel("Mode")
    axes[1].grid(True, alpha=0.25)

    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_presence_monitoring_plot(preprocessed: PreprocessedSession, output_path: Path) -> None:
    timestamps = preprocessed.session.timestamps_s
    peak_ranges = preprocessed.peak_range_m_per_frame
    smoothed_ranges = preprocessed.smoothed_peak_range_m
    active = preprocessed.presence_mask

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(
        timestamps,
        peak_ranges,
        color=jet_color(1, 4),
        linewidth=0.9,
        alpha=0.85,
        label="Instantaneous dominant range",
    )
    ax.plot(
        timestamps[active],
        smoothed_ranges[active],
        color=jet_color(3, 4),
        linewidth=2.0,
        label="Monitoring trace (smoothed)",
    )
    ax.scatter(
        timestamps[active],
        peak_ranges[active],
        s=10,
        color=jet_color(2, 4),
        alpha=0.55,
        label="Detected presence",
    )
    ax.set_title("Presence monitoring trace")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Range (m)")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper right")

    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_all_cfar_peaks_tap_plot(
    preprocessed: PreprocessedSession,
    detections_per_frame: list[list[CfarDetection]],
    output_path: Path,
) -> None:
    timestamps = preprocessed.session.timestamps_s
    det_t: list[float] = []
    det_tap: list[int] = []
    det_mag_db: list[float] = []

    for frame_idx, detections in enumerate(detections_per_frame):
        if frame_idx >= len(timestamps):
            break
        for detection in detections:
            det_t.append(float(timestamps[frame_idx]))
            det_tap.append(int(detection.tap_idx))
            det_mag_db.append(float(magnitude_to_db(np.asarray([detection.magnitude], dtype=np.float32))[0]))

    fig, ax = plt.subplots(figsize=(12, 5))
    if det_t:
        scatter = ax.scatter(
            det_t,
            det_tap,
            c=det_mag_db,
            s=16,
            cmap="jet",
            alpha=0.8,
            linewidths=0,
        )
        fig.colorbar(scatter, ax=ax, label="CFAR magnitude (dB)")
    ax.set_title(f"All CFAR peaks over time by tap (path {preprocessed.selected_path})")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Tap index")
    ax.grid(True, alpha=0.25)
    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_range_doppler_plot(preprocessed: PreprocessedSession, output_path: Path) -> None:
    signal = preprocessed.highpass_complex  # (N, K)
    N = signal.shape[0]

    window = np.hanning(N).reshape(-1, 1)
    rdm = np.fft.fftshift(np.fft.fft(signal * window, axis=0), axes=0)
    rdm_db = magnitude_to_db(np.abs(rdm))

    doppler_hz = np.fft.fftshift(np.fft.fftfreq(N, d=1.0 / preprocessed.frame_rate_hz))
    c = 3e8
    fc = preprocessed.config.carrier_frequency_hz
    velocity_ms = doppler_hz * c / (2.0 * fc)

    range_axis = preprocessed.range_axis_m
    valid = range_axis >= preprocessed.config.wall_clip_m
    vmin, vmax = db_limits(rdm_db[:, valid].T)

    fig, ax = plt.subplots(figsize=(11, 6))
    im = ax.imshow(
        rdm_db[:, valid].T,
        aspect="auto",
        origin="lower",
        extent=[velocity_ms[0], velocity_ms[-1], range_axis[valid][0], range_axis[valid][-1]],
        cmap="jet",
        vmin=vmin,
        vmax=vmax,
    )
    ax.axvline(0, color="white", linewidth=0.6, alpha=0.5, linestyle="--")
    ax.set_title(f"Range-Doppler map (path {preprocessed.selected_path}, fc={fc/1e9:.2f} GHz)")
    ax.set_xlabel("Radial velocity (m/s)  [negative = approaching, positive = receding]")
    ax.set_ylabel("Range (m)")
    fig.colorbar(im, ax=ax, label="Magnitude (dB)")
    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_multi_peak_tracking_plot(
    preprocessed: PreprocessedSession,
    confirmed_tracks: list[Track],
    output_path: Path,
) -> None:
    """Range trajectories of all confirmed CFAR tracks over time."""
    fig, ax = plt.subplots(figsize=(12, 5))
    track_count = max(len(confirmed_tracks), 1)

    for i, track in enumerate(confirmed_tracks):
        if len(track.history_t) < 2:
            continue
        ax.plot(track.history_t, track.history_m,
                color=jet_color(i, track_count),
                linewidth=1.5)
                #label=f"track {track.track_id}")

    ax.set_title("Confirmed track trajectories (CFAR + Kalman)")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Range (m)")
    ax.grid(True, alpha=0.3)
    if confirmed_tracks:
        ax.legend(loc="upper right", fontsize=8)
    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


def save_spectrogram_plot(
    spectrogram: SpectrogramResult,
    output_path: Path,
    frequency_limit_hz: float,
) -> None:
    fig, ax = plt.subplots(figsize=(11, 5))
    valid = np.abs(spectrogram.frequencies_hz) <= frequency_limit_hz
    freq = spectrogram.frequencies_hz[valid]
    mag = spectrogram.magnitude_db[valid]
    vmin, vmax = db_limits(mag)
    mesh = ax.pcolormesh(
        spectrogram.times_s,
        freq,
        mag,
        shading="auto",
        cmap="jet",
        vmin=vmin,
        vmax=vmax,
    )
    kind_label = "Phase micro-Doppler" if spectrogram.kind == "microdoppler" else spectrogram.kind.capitalize()
    ax.set_title(
        f"{kind_label} spectrogram "
        f"(path {spectrogram.selected_path}, tap {spectrogram.selected_tap}, "
        f"range {spectrogram.selected_range_m:.2f} m)"
    )
    ax.set_xlabel("Slow time (s)")
    ax.set_ylabel("Frequency (Hz)")
    fig.colorbar(mesh, ax=ax, label="Magnitude (dB)")
    plt.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Scientific Range-Doppler heatmap (jet, range on X, velocity on Y)
# ---------------------------------------------------------------------------

def _compute_rdm(
    signal: np.ndarray,
    frame_rate_hz: float,
    carrier_frequency_hz: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (rdm_db, range_valid_mask, velocity_ms) for a (N, K) complex signal."""
    N = signal.shape[0]
    win = np.hanning(N).reshape(-1, 1)
    rdm = np.fft.fftshift(np.fft.fft(signal * win, axis=0), axes=0)
    rdm_db = magnitude_to_db(np.abs(rdm))
    doppler_hz = np.fft.fftshift(np.fft.fftfreq(N, d=1.0 / frame_rate_hz))
    velocity_ms = doppler_hz * 3e8 / (2.0 * carrier_frequency_hz)
    return rdm_db, velocity_ms


def save_range_doppler_heatmap(
    preprocessed: PreprocessedSession,
    output_path: Path,
    vel_lim_ms: float = 3.0,
) -> None:
    """Scientific Range-Doppler heatmap: range on X, velocity on Y, jet colormap.

    Uses the full session FFT (all frames) to give a time-integrated view of
    target Doppler.  Saved as a publication-quality PNG.

    Parameters
    ----------
    vel_lim_ms:
        Half-range of the velocity axis in m/s (default 3.0 → shows −3 to +3).
        Clamped to the actual Nyquist velocity of the data if the data does not
        reach that speed.
    """
    import matplotlib.ticker as ticker

    signal = preprocessed.highpass_complex          # (N, K)
    range_axis = preprocessed.range_axis_m
    valid = range_axis >= preprocessed.config.wall_clip_m
    range_valid = range_axis[valid]

    rdm_db, velocity_ms = _compute_rdm(
        signal, preprocessed.frame_rate_hz, preprocessed.config.carrier_frequency_hz
    )
    # rdm_db shape: (N, K) — rows=Doppler bins, cols=range taps
    map_data = rdm_db[:, valid]                     # (N_doppler, N_range_valid)

    # clamp colour scale to [-20, peak] so faint targets stay visible
    vmin, vmax = db_limits(map_data)

    fig, ax = plt.subplots(figsize=(9, 5.5), facecolor="white")

    img = ax.pcolormesh(
        range_valid,
        velocity_ms,
        map_data,
        cmap="jet",
        vmin=vmin,
        vmax=vmax,
        shading="auto",
        rasterized=True,
    )

    cbar = fig.colorbar(img, ax=ax, pad=0.02)
    cbar.set_label("Power (dB)", fontsize=11)
    cbar.ax.tick_params(labelsize=9)

    v_lo = max(velocity_ms[0],  -vel_lim_ms)
    v_hi = min(velocity_ms[-1], +vel_lim_ms)

    ax.axhline(0, color="white", linewidth=0.7, linestyle="--", alpha=0.45)
    ax.set_xlabel("Range (m)", fontsize=12, color="black")
    ax.set_ylabel("Velocity (m/s)", fontsize=12, color="black")
    ax.set_xlim(range_valid[0], range_valid[-1])
    ax.set_ylim(v_lo, v_hi)
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1.0))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.5))
    ax.yaxis.set_major_locator(ticker.MultipleLocator(0.5))
    ax.yaxis.set_minor_locator(ticker.MultipleLocator(0.25))
    ax.tick_params(axis="y", which="major", labelsize=9, color="black", labelcolor="black", length=5)
    ax.tick_params(axis="y", which="minor", labelsize=0,  color="black", length=3)
    ax.tick_params(axis="x", which="both",  labelsize=9, color="black", labelcolor="black")
    ax.yaxis.grid(True, which="major", color="white", linewidth=0.4, alpha=0.25, linestyle="-")
    ax.yaxis.grid(True, which="minor", color="white", linewidth=0.2, alpha=0.12, linestyle=":")
    ax.set_axisbelow(False)
    for spine in ax.spines.values():
        spine.set_edgecolor("black")

    fc_ghz = preprocessed.config.carrier_frequency_hz / 1e9
    ax.set_title(
        f"Range-Doppler Map  (path {preprocessed.selected_path}, "
        f"fc = {fc_ghz:.2f} GHz)",
        fontsize=12, color="black",
    )
    fig.text(
        0.5, 0.01,
        "Range-Doppler map showing two targets and Doppler ambiguity replicas.",
        ha="center", va="bottom", fontsize=9, color="#444444", style="italic",
    )

    fig.tight_layout(rect=[0, 0.04, 1, 1])
    fig.savefig(output_path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def save_range_doppler_heatmap_animation(
    preprocessed: PreprocessedSession,
    output_path: Path,
    window_frames: int | None = None,
    step_frames: int | None = None,
    fps: int = 15,
    vel_lim_ms: float = 3.0,
) -> None:
    """Animated Range-Doppler map using a sliding window through the session.

    Encodes directly to MP4 via OpenCV VideoWriter (no ffmpeg binary required).

    Parameters
    ----------
    window_frames:
        FFT window length in frames.  Defaults to min(256, N//4), floor 32.
    step_frames:
        Frames to advance between animation frames.  Defaults to window//8.
    fps:
        Output video frame rate.
    vel_lim_ms:
        Half-range of the velocity axis in m/s (default 3.0 → shows −3 to +3).
    """
    import cv2
    import matplotlib.ticker as ticker

    signal = preprocessed.highpass_complex          # (N, K)
    N = signal.shape[0]
    range_axis = preprocessed.range_axis_m
    valid = range_axis >= preprocessed.config.wall_clip_m
    range_valid = range_axis[valid]
    timestamps = preprocessed.session.timestamps_s

    # window / step sizing
    win_len = window_frames or max(32, min(256, N // 4))
    win_len = min(win_len, N)
    step = step_frames or max(1, win_len // 8)

    # pre-compute colour limits from a representative middle window
    mid = max(0, (N - win_len) // 2)
    rdm_mid, velocity_ms = _compute_rdm(
        signal[mid: mid + win_len],
        preprocessed.frame_rate_hz,
        preprocessed.config.carrier_frequency_hz,
    )
    map_mid = rdm_mid[:, valid]
    vmin, vmax = db_limits(map_mid)

    # --- build figure once; reuse for each frame ---
    DPI = 120
    fig, ax = plt.subplots(figsize=(9, 5.5), facecolor="white")

    img = ax.pcolormesh(
        range_valid,
        velocity_ms,
        map_mid,
        cmap="jet",
        vmin=vmin,
        vmax=vmax,
        shading="auto",
        rasterized=True,
    )
    cbar = fig.colorbar(img, ax=ax, pad=0.02)
    cbar.set_label("Power (dB)", fontsize=11)
    cbar.ax.tick_params(labelsize=9)

    v_lo = max(velocity_ms[0],  -vel_lim_ms)
    v_hi = min(velocity_ms[-1], +vel_lim_ms)

    ax.axhline(0, color="white", linewidth=0.7, linestyle="--", alpha=0.45)
    ax.set_xlabel("Range (m)", fontsize=12, color="black")
    ax.set_ylabel("Velocity (m/s)", fontsize=12, color="black")
    ax.set_xlim(range_valid[0], range_valid[-1])
    ax.set_ylim(v_lo, v_hi)
    ax.xaxis.set_major_locator(ticker.MultipleLocator(1.0))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.5))
    ax.yaxis.set_major_locator(ticker.MultipleLocator(0.5))
    ax.yaxis.set_minor_locator(ticker.MultipleLocator(0.25))
    ax.tick_params(axis="y", which="major", labelsize=9, color="black", labelcolor="black", length=5)
    ax.tick_params(axis="y", which="minor", labelsize=0,  color="black", length=3)
    ax.tick_params(axis="x", which="both",  labelsize=9, color="black", labelcolor="black")
    ax.yaxis.grid(True, which="major", color="white", linewidth=0.4, alpha=0.25, linestyle="-")
    ax.yaxis.grid(True, which="minor", color="white", linewidth=0.2, alpha=0.12, linestyle=":")
    ax.set_axisbelow(False)
    for spine in ax.spines.values():
        spine.set_edgecolor("black")

    title = ax.set_title("Range-Doppler Map Over Time - Frame 001", fontsize=12, color="black")
    fig.text(
        0.5, 0.01,
        "Range-Doppler map showing two targets and Doppler ambiguity replicas.",
        ha="center", va="bottom", fontsize=9, color="#444444", style="italic",
    )
    fig.tight_layout(rect=[0, 0.04, 1, 1])

    # determine output pixel dimensions (must be even for mp4v codec)
    fig.canvas.draw()
    buf = fig.canvas.buffer_rgba()
    frame0_rgba = np.asarray(buf)
    h, w = frame0_rgba.shape[:2]
    h = h if h % 2 == 0 else h - 1
    w = w if w % 2 == 0 else w - 1

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(str(output_path), fourcc, fps, (w, h))

    starts = list(range(0, N - win_len + 1, step))
    n_anim = len(starts)

    for anim_idx, start in enumerate(starts):
        chunk = signal[start: start + win_len]
        rdm_db, _ = _compute_rdm(
            chunk,
            preprocessed.frame_rate_hz,
            preprocessed.config.carrier_frequency_hz,
        )
        img.set_array(rdm_db[:, valid].ravel())

        t_centre = float(timestamps[start + win_len // 2]) if (start + win_len // 2) < len(timestamps) else float(start + win_len // 2) / preprocessed.frame_rate_hz
        title.set_text(
            f"Range-Doppler Map Over Time - Frame {anim_idx + 1:03d}  "
            f"(t = {t_centre:.2f} s)"
        )
        fig.canvas.draw()

        buf = fig.canvas.buffer_rgba()
        rgba = np.asarray(buf)[:h, :w, :3]
        bgr = rgba[:, :, ::-1].copy()
        writer.write(bgr)

        if (anim_idx + 1) % 20 == 0 or anim_idx == n_anim - 1:
            print(f"  [rdm anim] frame {anim_idx + 1:03d}/{n_anim}")

    writer.release()
    plt.close(fig)


def save_fov_polar_plot(
    track_aoas_per_frame: list[list[TrackAoA]],
    fov_limit_deg: float,
    output_path: Path,
    range_max_m: float = 7.5,
) -> None:
    """Static polar-sector FOV plot aggregating all frame track AoA positions.

    Shows angle (horizontal axis) vs. range (radial) up to range_max_m for
    every confirmed track across the full session.
    """
    track_points: dict[int, tuple[list[float], list[float]]] = {}
    for frame_aoas in track_aoas_per_frame:
        for ta in frame_aoas:
            if ta.range_m > range_max_m:
                continue
            if ta.track_id not in track_points:
                track_points[ta.track_id] = ([], [])
            track_points[ta.track_id][0].append(float(np.deg2rad(ta.angle_deg)))
            track_points[ta.track_id][1].append(float(ta.range_m))

    n_tracks = max(track_points.keys(), default=0) + 1

    fig = plt.figure(figsize=(8, 7), facecolor="white")
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_zero_location("N")
    ax.set_theta_direction(-1)
    ax.set_thetamin(-fov_limit_deg)
    ax.set_thetamax(fov_limit_deg)
    ax.set_rlim(0.0, range_max_m)
    ax.set_title(
        f"Field of View  (±{fov_limit_deg:.0f}°,  {range_max_m:.1f} m range)",
        pad=18, fontsize=12,
    )

    r_ticks = np.arange(1.0, range_max_m + 0.01, 1.0)
    ax.set_rticks(r_ticks.tolist())
    ax.set_rlabel_position(fov_limit_deg * 0.6)
    ax.yaxis.set_tick_params(labelsize=8)
    ax.set_thetagrids(
        np.arange(-fov_limit_deg, fov_limit_deg + 1, 15.0).tolist(),
        fontsize=8,
    )
    ax.grid(True, alpha=0.35, linewidth=0.6)

    if not track_points:
        ax.text(
            0.5, 0.5, "No tracks in FOV",
            transform=ax.transAxes, ha="center", va="center",
            fontsize=11, color="gray",
        )
    else:
        for tid, (thetas, ranges) in sorted(track_points.items()):
            color = jet_color(tid, n_tracks)
            ax.scatter(thetas, ranges, s=10, color=[color], alpha=0.6, linewidths=0)

    fig.tight_layout()
    fig.savefig(output_path, dpi=160, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def save_fov_animation(
    track_aoas_per_frame: list[list[TrackAoA]],
    timestamps_s: np.ndarray,
    fov_limit_deg: float,
    output_path: Path,
    range_max_m: float = 7.5,
    fps: int = 10,
    trail_s: float = 2.0,
) -> None:
    """Animate the polar FOV sector frame-by-frame with a fading trail, saved as MP4."""
    import imageio.v2 as imageio

    output_path = Path(output_path)
    partial = output_path.with_name(f"{output_path.stem}.partial{output_path.suffix}")
    if partial.exists():
        partial.unlink()

    n_frames = len(track_aoas_per_frame)
    all_ids = [ta.track_id for frame in track_aoas_per_frame for ta in frame]
    n_tracks = (max(all_ids) + 1) if all_ids else 1

    dt = float(timestamps_s[1] - timestamps_s[0]) if len(timestamps_s) > 1 else 0.05
    trail_frames = max(1, int(trail_s / dt))

    # ------------------------------------------------------------------
    # Build figure ONCE — only scatter artists change per frame.
    # This avoids figure allocation / axes setup overhead on every frame,
    # giving ~10x speedup over creating a new figure per frame.
    # ------------------------------------------------------------------
    fig = plt.figure(figsize=(7, 7), facecolor="black")
    ax = fig.add_subplot(111, projection="polar")
    ax.set_facecolor("#080818")
    ax.set_theta_zero_location("N")
    ax.set_theta_direction(-1)
    ax.set_thetamin(-fov_limit_deg)
    ax.set_thetamax(fov_limit_deg)
    ax.set_rlim(0.0, range_max_m)
    ax.set_rticks(np.arange(1.0, range_max_m + 0.01, 1.0).tolist())
    ax.set_rlabel_position(fov_limit_deg * 0.55)
    ax.yaxis.set_tick_params(labelsize=7, labelcolor="#888888")
    ax.set_thetagrids(np.arange(-fov_limit_deg, fov_limit_deg + 1, 15.0).tolist(), fontsize=7)
    for lbl in ax.get_xticklabels():
        lbl.set_color("#888888")
    ax.grid(True, alpha=0.2, linewidth=0.5, color="#aaaaaa")
    title = ax.set_title("FOV  t = 0.00 s", color="white", pad=12, fontsize=11)
    fig.tight_layout()
    fig.canvas.draw()

    # Pre-compute RGBA base colors per track id
    track_rgba: dict[int, tuple[float, float, float, float]] = {
        tid: jet_color(tid, n_tracks) for tid in range(n_tracks)
    }

    dynamic: list = []   # scatter artists removed each frame

    print(f"[fov anim] writing {n_frames} frames → {partial.name}")
    try:
        with imageio.get_writer(str(partial), fps=fps, codec="libx264") as writer:
            for fi in range(n_frames):
                if fi == 0 or fi == n_frames - 1 or fi % 50 == 0:
                    print(f"[fov anim] frame {fi + 1}/{n_frames}")

                # Remove previous scatter batch
                for a in dynamic:
                    a.remove()
                dynamic.clear()

                t_now = float(timestamps_s[fi]) if fi < len(timestamps_s) else fi * dt
                title.set_text(f"FOV  t = {t_now:.2f} s")

                # Collect all trail points into a single scatter call (per-point RGBA)
                thetas: list[float] = []
                ranges: list[float] = []
                sizes: list[float] = []
                colors: list[tuple[float, float, float, float]] = []

                for trail_fi in range(max(0, fi - trail_frames), fi + 1):
                    age = fi - trail_fi
                    frac = 1.0 - age / trail_frames
                    alpha = max(0.05, frac ** 1.5)
                    size = 6.0 + 54.0 * frac
                    for ta in track_aoas_per_frame[trail_fi]:
                        if ta.range_m > range_max_m:
                            continue
                        r, g, b, _ = track_rgba.get(ta.track_id, (1.0, 1.0, 1.0, 1.0))
                        thetas.append(float(np.deg2rad(ta.angle_deg)))
                        ranges.append(ta.range_m)
                        sizes.append(size)
                        colors.append((r, g, b, alpha))

                if thetas:
                    sc = ax.scatter(
                        np.asarray(thetas, dtype=np.float32),
                        np.asarray(ranges, dtype=np.float32),
                        s=np.asarray(sizes, dtype=np.float32),
                        c=np.asarray(colors, dtype=np.float32),
                        linewidths=0,
                    )
                    dynamic.append(sc)

                fig.canvas.draw()
                rgb = np.asarray(fig.canvas.buffer_rgba(), dtype=np.uint8)[..., :3].copy()
                writer.append_data(rgb)

        plt.close(fig)
        partial.replace(output_path)
        print(f"[fov anim] wrote {output_path.name}")
    except Exception:
        plt.close(fig)
        if partial.exists():
            partial.unlink()
        raise
