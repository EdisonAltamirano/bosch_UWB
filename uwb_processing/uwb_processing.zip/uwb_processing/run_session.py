from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np

if __package__ in {None, ""}:
    package_root = Path(__file__).resolve().parents[1]
    if str(package_root) not in sys.path:
        sys.path.insert(0, str(package_root))

    from uwb_processing.annotations import load_annotation_file
    from uwb_processing.aoa import estimate_track_aoa_session, pair_rx_channels
    from uwb_processing.breathing import run_breathing_extraction
    from uwb_processing.cfar import combine_paths_max, merge_dual_channel_peaks, run_cfar_session
    from uwb_processing.detection import detect_window
    from uwb_processing.loaders import load_session
    from uwb_processing.plotting import (
        save_fov_animation,
        save_fov_polar_plot,
        save_multi_peak_tracking_plot,
        save_range_doppler_heatmap,
        save_range_time_plot,
        save_spectrogram_plot,
    )
    from uwb_processing.preprocessing import preprocess_session
    from uwb_processing.tracker import MultiTargetTracker
    from uwb_processing.types import CfarDetectionConfig, DetectionConfig, TrackingConfig
else:
    from .annotations import load_annotation_file
    from .aoa import estimate_track_aoa_session, pair_rx_channels
    from .breathing import run_breathing_extraction
    from .cfar import combine_paths_max, merge_dual_channel_peaks, run_cfar_session
    from .detection import detect_window
    from .loaders import load_session
    from .plotting import (
        save_fov_animation,
        save_fov_polar_plot,
        save_multi_peak_tracking_plot,
        save_range_doppler_heatmap,
        save_range_time_plot,
        save_spectrogram_plot,
    )
    from .preprocessing import preprocess_session
    from .tracker import MultiTargetTracker
    from .types import CfarDetectionConfig, DetectionConfig, TrackingConfig


_REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SESSION_NAME = "single_person_walking_preset_2ms"


# ---------------------------------------------------------------------------
# CLI helpers
# ---------------------------------------------------------------------------

def _default_input_path(all_rosbags: bool = False) -> Path:
    if all_rosbags:
        return _REPO_ROOT / "uwb_rosbags"
    return _REPO_ROOT / "uwb_rosbags" / DEFAULT_SESSION_NAME

def _discover_session_inputs(path: Path, all_rosbags: bool = False) -> list[Path]:
    """Return [path] unless all_rosbags=True, in which case scan for rosbag/npz dirs."""
    if not all_rosbags:
        return [path]
    results: list[Path] = []
    for child in sorted(path.iterdir()):
        if not child.is_dir():
            continue
        if (child / "metadata.yaml").exists():
            results.append(child)
        elif any(child.glob("*.npz")):
            results.append(child)
    return results


def _resolve_annotation_path(
    session_dir: Path,
    annotation_path: Path | None,
    annotations_root: Path | None,
) -> Path | None:
    if annotation_path is not None:
        return annotation_path
    if annotations_root is not None:
        candidate = annotations_root / f"{session_dir.name}.yaml"
        if candidate.exists():
            return candidate
    return None


def _resolve_output_dir(
    session_dir: Path,
    output_root: Path | None,
    batch_mode: bool = False,
) -> Path:
    if batch_mode and output_root is not None:
        return output_root / session_dir.name
    if output_root is not None:
        return output_root
    return session_dir / "analysis"


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run offline UWB session processing.")
    parser.add_argument(
        "--input",
        help=f"Path to rosbag or npz directory. Default: uwb_rosbags/{DEFAULT_SESSION_NAME}",
    )
    parser.add_argument("--annotation", help="Path to annotation YAML.")
    parser.add_argument("--annotations-root", help="Directory to search for per-session annotations.")
    parser.add_argument("--output-dir", help="Directory for output artifacts.")
    parser.add_argument("--all-rosbags", action="store_true",
                        help="Process all sessions found under --input.")
    parser.add_argument("--topic", default="/uwb/frame_raw")
    parser.add_argument("--range-resolution-m", type=float, default=0.15)
    parser.add_argument("--default-range-min-m", type=float, default=0.3)
    parser.add_argument("--default-range-max-m", type=float, default=6.0)
    parser.add_argument("--wall-clip-m", type=float, default=0.3)
    parser.add_argument("--motion-threshold", type=float, default=3.0)
    parser.add_argument("--background-window-s", type=float, default=1.5)
    parser.add_argument("--doppler-window-s", type=float, default=4.0)
    parser.add_argument("--microdoppler-window-s", type=float, default=1.5)
    parser.add_argument("--stft-overlap", type=float, default=0.75)
    parser.add_argument("--top-k-taps", type=int, default=6)
    return parser


def config_from_args(args: argparse.Namespace) -> DetectionConfig:
    return DetectionConfig(
        tap_spacing_m=float(getattr(args, "range_resolution_m", 0.15)),
        default_range_gate_m=(
            float(getattr(args, "default_range_min_m", 0.3)),
            float(getattr(args, "default_range_max_m", 6.0)),
        ),
        wall_clip_m=float(getattr(args, "wall_clip_m", 0.3)),
        motion_threshold=float(getattr(args, "motion_threshold", 3.0)),
        doppler_window_s=float(getattr(args, "doppler_window_s", 4.0)),
        microdoppler_window_s=float(getattr(args, "microdoppler_window_s", 1.5)),
        stft_overlap=float(getattr(args, "stft_overlap", 0.75)),
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _per_path_clutter_mag(preprocessed, path_idx: int) -> np.ndarray:
    """Clutter-removed magnitude for a single RX path (batch mean subtraction)."""
    frames = preprocessed.session.frames          # (F, P, T) complex
    global_mean = frames.mean(axis=0, keepdims=True)
    clutter = np.abs(frames - global_mean).astype(np.float32)
    wall_mask = preprocessed.range_axis_m >= preprocessed.config.wall_clip_m
    path_mag = clutter[:, path_idx, :].copy()
    path_mag[:, ~wall_mask] = 0.0
    return path_mag


def _save_detections_csv(
    detections_per_frame: list[list],
    timestamps_s: np.ndarray,
    output_path: Path,
) -> None:
    fields = ["frame_idx", "timestamp_s", "tap_idx", "range_m", "magnitude", "threshold"]
    with output_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for fi, dets in enumerate(detections_per_frame):
            t_s = float(timestamps_s[fi]) if fi < len(timestamps_s) else float(fi) * 0.01
            for d in dets:
                writer.writerow({
                    "frame_idx": d.frame_idx,
                    "timestamp_s": round(t_s, 6),
                    "tap_idx": d.tap_idx,
                    "range_m": round(d.range_m, 4),
                    "magnitude": round(d.magnitude, 6),
                    "threshold": round(d.threshold, 6),
                })


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------

_FOV_LIMIT_DEG = 60.0
_FOV_RX_SPACING_M = 0.108
_FOV_RANGE_MAX_M = 7.5


def process_session(
    input_path: Path,
    annotation_path: Path | None,
    output_dir: Path,
    config: DetectionConfig,
    topic: str = "/uwb/frame_raw",
) -> tuple[dict[str, Any], Path]:
    """Run the full offline pipeline and save all required artifacts.

    Follows the step-by-step procedure in ground_truth/uwb_radar_processing_guide.tex.

    Returns
    -------
    summary : dict  — JSON-serialisable session summary (used by batch_eval aggregation)
    output_dir : Path — directory where all artifacts were written
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Load and preprocess
    session = load_session(input_path, topic=topic)
    preprocessed = preprocess_session(session, config)

    # 2. Session-level plots (guide §2.3, §6)
    save_range_time_plot(preprocessed, output_dir / "range_time.png")
    save_range_doppler_heatmap(preprocessed, output_dir / "range_doppler.png")

    # 3. CFAR detection with dual-channel merge (guide §3.1, §5.2)
    cfar_cfg = CfarDetectionConfig(
        num_ref_cells=8, num_guard_cells=2, pfa=1e-2, max_peaks_per_frame=4
    )
    n_paths = session.frames.shape[1]
    if n_paths >= 2:
        dets_c = run_cfar_session(preprocessed, cfar_cfg,
                                  clutter_mag=_per_path_clutter_mag(preprocessed, 0))
        dets_b = run_cfar_session(preprocessed, cfar_cfg,
                                  clutter_mag=_per_path_clutter_mag(preprocessed, 1))
        detections_per_frame = [
            merge_dual_channel_peaks(c, b, fi, preprocessed.range_axis_m)
            for fi, (c, b) in enumerate(zip(dets_c, dets_b))
        ]
    else:
        combined_mag = combine_paths_max(preprocessed)
        detections_per_frame = run_cfar_session(preprocessed, cfar_cfg, clutter_mag=combined_mag)

    # 4. Kalman tracking (guide §3.4)
    dt_s = 1.0 / max(preprocessed.frame_rate_hz, 1.0)
    tracker_cfg = TrackingConfig(
        dt_s=dt_s,
        sigma_meas_m=0.15,
        gate_distance_m=0.45,
        confirm_hits=2,
        max_misses=15,
        init_hits=2,
        init_window_frames=5,
    )
    tracker = MultiTargetTracker(tracker_cfg)
    tracks_per_frame: list[list] = []
    for fi, dets in enumerate(detections_per_frame):
        t_s = float(session.timestamps_s[fi]) if fi < len(session.timestamps_s) else float(fi) * dt_s
        tracks_per_frame.append(tracker.update(fi, t_s, dets))

    all_tracks = tracker.tracks_snapshot()
    save_multi_peak_tracking_plot(preprocessed, all_tracks, output_dir / "peak_tracking.png")

    # FOV polar plot (angle × range sector view, requires dual-RX for AoA)
    # if session.frames.shape[1] >= 2:
    #     try:
    #         paired = pair_rx_channels(session)
    #         track_aoas_per_frame = estimate_track_aoa_session(
    #             paired,
    #             detections_per_frame,
    #             tracks_per_frame,
    #             carrier_frequency_hz=preprocessed.config.carrier_frequency_hz,
    #             rx_spacing_m=_FOV_RX_SPACING_M,
    #             fov_limit_deg=_FOV_LIMIT_DEG,
    #         )
    #         save_fov_polar_plot(
    #             track_aoas_per_frame,
    #             fov_limit_deg=_FOV_LIMIT_DEG,
    #             output_path=output_dir / "fov.png",
    #             range_max_m=_FOV_RANGE_MAX_M,
    #         )
    #         save_fov_animation(
    #             track_aoas_per_frame,
    #             session.timestamps_s,
    #             fov_limit_deg=_FOV_LIMIT_DEG,
    #             output_path=output_dir / "fov.mp4",
    #             range_max_m=_FOV_RANGE_MAX_M,
    #         )
    #     except ValueError as exc:
    #         print(f"[fov] skipped: {exc}")

    # 5. Breathing extraction from each confirmed track (guide §4)
    breathing_results: list[dict[str, Any]] = []
    for track in all_tracks:
        if len(track.history_t) < 32:
            continue
        ts = session.timestamps_s
        t_start, t_end = float(min(track.history_t)), float(max(track.history_t))
        frame_mask = (ts >= t_start) & (ts <= t_end)
        mean_range_m = float(np.mean(track.history_m))
        track_tap = int(np.clip(
            round(mean_range_m / preprocessed.config.tap_spacing_m),
            0, preprocessed.highpass_complex.shape[1] - 1,
        ))
        br = run_breathing_extraction(
            preprocessed.highpass_complex,
            preprocessed.peak_tap_per_frame,
            frame_mask,
            track_tap,
            preprocessed.frame_rate_hz,
        )
        breathing_results.append({
            "track_id": track.track_id,
            "tap_idx": br.tap_idx,
            "is_static": br.is_static,
            "freq_hz": br.freq_hz,
            "freq_bpm": br.freq_bpm,
            "snr_db": br.snr_db,
            "phase_arc_deg": br.phase_arc_deg,
        })

    # 6. Per-window annotation analysis (guide §4, §7)
    window_results: list[dict[str, Any]] = []
    if annotation_path is not None:
        annotation = load_annotation_file(annotation_path)
        for window in annotation.windows:
            window_dir = output_dir / window.label
            window_dir.mkdir(parents=True, exist_ok=True)
            try:
                det_result, extras = detect_window(preprocessed, window, artifact_dir=window_dir)
                save_spectrogram_plot(
                    extras["doppler"],
                    window_dir / "doppler.png",
                    frequency_limit_hz=config.doppler_limit_hz,
                )
                save_spectrogram_plot(
                    extras["microdoppler"],
                    window_dir / "microdoppler.png",
                    frequency_limit_hz=config.microdoppler_limit_hz,
                )
                window_results.append(det_result.to_dict())
            except (ValueError, RuntimeError):
                pass

    # 7. Artifacts: detections.csv and summary.json
    _save_detections_csv(detections_per_frame, session.timestamps_s, output_dir / "detections.csv")

    summary: dict[str, Any] = {
        "session_id": session.session_id,
        "frame_count": int(session.frames.shape[0]),
        "frame_rate_hz": float(preprocessed.frame_rate_hz),
        "duration_s": float(session.timestamps_s[-1]) if session.timestamps_s.size > 0 else 0.0,
        "selected_path": int(preprocessed.selected_path),
        "dominant_tap": int(preprocessed.dominant_tap),
        "dominant_range_m": float(preprocessed.range_axis_m[preprocessed.dominant_tap]),
        "detections": window_results,
        "confirmed_tracks": [
            {
                "track_id": t.track_id,
                "history_length": len(t.history_m),
                "mean_range_m": float(np.mean(t.history_m)) if t.history_m else 0.0,
            }
            for t in all_tracks
        ],
        "breathing": breathing_results,
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, indent=2))

    return summary, output_dir


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    input_path = Path(args.input) if args.input else _default_input_path(all_rosbags=args.all_rosbags)
    output_root = Path(args.output_dir) if args.output_dir else None
    annotation_path = Path(args.annotation) if args.annotation else None
    annotations_root = Path(args.annotations_root) if getattr(args, "annotations_root", None) else None
    config = config_from_args(args)

    session_inputs = _discover_session_inputs(input_path, all_rosbags=args.all_rosbags)

    for session_path in session_inputs:
        output_dir = _resolve_output_dir(session_path, output_root, batch_mode=args.all_rosbags)
        resolved_ann = _resolve_annotation_path(session_path, annotation_path, annotations_root)
        summary, out_dir = process_session(
            input_path=session_path,
            annotation_path=resolved_ann,
            output_dir=output_dir,
            config=config,
            topic=args.topic,
        )
        print(json.dumps({"session": summary["session_id"], "output_dir": str(out_dir)}, indent=2))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
