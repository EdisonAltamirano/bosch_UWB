# uwb_processing Pipeline — Engineering Reference

This file governs all DSP, detection, and tracking work inside this package.
Read it before touching `cfar.py`, `tracker.py`, `run_session.py`, or `types.py`.

---

## 1  Working Pipeline — What Runs Today

`run_session.py:process_session` is the canonical entry point.  It produces all
required artifacts in this order:

| Step | Code location | Output artifact |
|------|---------------|-----------------|
| Load + preprocess | `loaders.py` → `preprocessing.py` | — |
| Range-time plot | `plotting.py:save_range_time_plot` | `range_time.png` |
| Range-Doppler heatmap | `plotting.py:save_range_doppler_heatmap` | `range_doppler.png` |
| 1-D OS/CA-CFAR on clutter-removed magnitude | `cfar.py:run_cfar_session` | — |
| Dual-channel peak merge | `cfar.py:merge_dual_channel_peaks` | — |
| EKF tracker (1-D range + optional radial velocity) | `tracker.py:MultiTargetTracker` | `peak_tracking.png` |
| Doppler animation | `plotting.py:save_doppler_animation` | `doppler.mp4` |
| AoA / FOV | `aoa.py` | `range_azimuth.mp4` (commented out) |
| Breathing extraction | `breathing.py:run_breathing_extraction` | in `summary.json` |
| Per-window spectrograms | `detection.py:detect_window` | `doppler.png`, `microdoppler.png` |
| Detections table | `run_session.py:_save_detections_csv` | `detections.csv` |
| Session summary | inline in `process_session` | `summary.json` |

Run a single session:

```
python -m uwb_processing.run_session \
  --input uwb_rosbags/breathing_kaytlin_edison
```

Run all bags:

```
python -m uwb_processing.run_session --all-rosbags
```

---

## 2  CFAR Upgrade — OS-CFAR on Range-Doppler Map

### Current behaviour (`cfar.py`)

`cfar_1d` runs a 1-D CA/OS/SO/GO window on the **range-only** clutter-removed
magnitude profile for every slow-time frame independently.  Detections have only
`range_m`; radial velocity is not estimated.

### Target behaviour (per Jiang & Guo IGARSS 2025, §III-A)

Apply OS-CFAR to the **range-Doppler map** produced by a slow-time FFT across a
sliding window of chirps (or frames).  Each detection then carries both `range_m`
and `range_rate_m_s`, which feeds directly into the EKF update.

#### Implementation plan

1. **Compute per-frame range-Doppler slice** (`cfar.py` or new `range_doppler_cfar.py`):

   ```python
   # frames: (F, P, T) complex — slow-time × path × tap
   # Take a window of W frames centered on frame fi
   window = frames[max(0, fi-W//2) : fi+W//2+1, path_idx, :]  # (W, T)
   rd_map = np.abs(np.fft.fftshift(np.fft.fft(window, axis=0), axes=0))  # (W, T)
   doppler_axis_mps = np.fft.fftshift(np.fft.fftfreq(W, d=dt_s)) * wavelength_m / 2
   ```

   Use `W = int(doppler_window_s * frame_rate_hz)` (already in `DetectionConfig`).

2. **Apply 2-D OS-CFAR** or 1-D OS-CFAR per Doppler bin:

   ```python
   # For each Doppler bin d, run cfar_1d on rd_map[d, :]
   # Collect (range_bin, doppler_bin) detection pairs
   ```

   Recommended parameters: `num_ref_cells=8, num_guard_cells=2, pfa=1e-2,
   variant="OS", os_rank=12`.

3. **Populate `CfarDetection.range_rate_m_s`** (already in `types.py`) from the
   Doppler bin index:

   ```python
   det.range_rate_m_s = float(doppler_axis_mps[doppler_bin])
   ```

4. Wire into `process_session` as an opt-in path controlled by a flag
   `--cfar-mode` (`"range_only"` | `"range_doppler"`).  The existing 1-D path
   remains the default so existing results do not change without opt-in.

---

## 3  EKF Upgrade — Group Tracking with Mahalanobis Gating

### Current behaviour (`tracker.py`)

`MultiTargetTracker` maintains 1-D state `[range_m, range_rate_m_s]`.  It now
uses chi-squared Mahalanobis gating with a coarse `gate_distance_m` pre-filter,
and it consumes `CfarDetection.range_rate_m_s` when available during both track
promotion and measurement updates.  Track initiation is still pool-based, but
the promoted state now bootstraps velocity from the tentative detections so a
single missed frame is less likely to spawn a new ID.

### Target behaviour (per Jiang & Guo IGARSS 2025, §III-B)

The paper uses a **2-D Cartesian EKF** with a nonlinear polar measurement model
that jointly observes range, azimuth, and radial velocity.  For this sensor — which
provides 1-D range and optionally PDoA azimuth — a practical intermediate step is:

**Step A (no AoA):** Keep 1-D state but add radial velocity as a second measurement.

**Step B (AoA available):** Promote to 2-D Cartesian state.

Both steps share the same gating and initiation improvements below.

---

### 3.1  Mahalanobis Distance Gating (implemented)

Current gate (`tracker.py:98`):

```python
range_gap = abs(pred_r - det.range_m)
if range_gap > self.cfg.gate_distance_m:
    continue
cost[ti, di] = range_gap
```

Current code now uses a chi-squared Mahalanobis gate (paper eq. 14):

```python
# H: measurement Jacobian (1×2 for range-only, 2×2 for range+velocity)
H   = self._measurement_jacobian(track.state)
S   = H @ track.covariance @ H.T + R          # innovation covariance
z_pred = self._measurement_prediction(track.state)
innov  = np.array([det.range_m - z_pred[0]])  # add velocity term if available
mah2   = float(innov.T @ np.linalg.inv(S) @ innov)
GATE   = 9.21   # chi²(2 dof, p=0.99) — tune from 5.99 (p=0.95) to 13.82 (p=0.999)
if mah2 > GATE:
    continue
cost[ti, di] = float(np.sqrt(mah2))
```

`TrackingConfig` now includes `gate_chi2: float = 9.21`.  `gate_distance_m`
remains a cheap pre-filter before the covariance-weighted gate is evaluated.

---

### 3.2  Velocity Measurement in the EKF Update (implemented when available)

When `CfarDetection.range_rate_m_s is not None`, the tracker now performs a
2-measurement update:

```python
# 2-measurement update: z = [range_m, range_rate_m_s]
H = np.array([[1.0, 0.0],   # range maps to state[0]
              [0.0, 1.0]])   # velocity maps to state[1]
R = np.diag([sigma_meas_m**2, sigma_meas_v**2])
z_meas = np.array([det.range_m, det.range_rate_m_s])
```

`TrackingConfig` now includes `sigma_meas_v: float = 0.15` (m/s).

---

### 3.3  2-D Cartesian EKF (Step B — requires AoA)

State: `x = [x_m, y_m, vx_mps, vy_mps]`  (shape (4,))

State transition (paper eq. 6):

```python
F = np.array([[1, 0, dt, 0],
              [0, 1, 0,  dt],
              [0, 0, 1,  0 ],
              [0, 0, 0,  1 ]])
```

Nonlinear measurement model (paper eq. 9):

```python
def h(x):
    r   = np.sqrt(x[0]**2 + x[1]**2 + 1e-12)
    az  = np.arctan2(x[1], x[0])
    rdot = (x[0]*x[2] + x[1]*x[3]) / r
    return np.array([r, az, rdot])
```

Jacobian `H_k` (linearise around predicted state for EKF):

```python
def H_jacobian(x):
    r2  = x[0]**2 + x[1]**2 + 1e-12
    r   = np.sqrt(r2)
    vr  = (x[0]*x[2] + x[1]*x[3]) / r
    drdx  = x[0]/r;          drdy  = x[1]/r
    dazdx = -x[1]/r2;        dazdy =  x[0]/r2
    drdotdx = (x[2]*r2 - x[0]*r*vr) / r2  / r   # simplified
    drdotdy = (x[3]*r2 - x[1]*r*vr) / r2  / r
    drdotvx = x[0]/r
    drdotvy = x[1]/r
    return np.array([
        [drdx,    drdy,    0,       0      ],
        [dazdx,   dazdy,   0,       0      ],
        [drdotdx, drdotdy, drdotvx, drdotvy],
    ])
```

Enable Step B only when `pair_rx_channels` succeeds and AoA data is available.
Gate: chi²(3 dof, p=0.99) → threshold = 11.34.

---

### 3.4  DBSCAN Track Initiation (replace pool-based counting)

Current: pool entry promoted when hit_count >= init_hits within init_window_frames.
Paper: DBSCAN on unassigned detections each frame; new tracks created only for
dense clusters (avoids creating tentative tracks for isolated noise detections).

```python
from sklearn.cluster import DBSCAN

unassigned = [detections[di] for di in range(len(detections)) if di not in assigned_dets]
if len(unassigned) >= 2:
    coords = np.array([[d.range_m, d.range_rate_m_s or 0.0] for d in unassigned])
    labels = DBSCAN(eps=gate_distance_m, min_samples=2).fit_predict(coords)
    for label in set(labels):
        if label == -1:
            continue
        cluster_dets = [unassigned[i] for i, l in enumerate(labels) if l == label]
        mean_range = np.mean([d.range_m for d in cluster_dets])
        self._promote_cluster(mean_range, frame_idx, timestamp_s)
```

Add `use_dbscan_init: bool = False` to `TrackingConfig` (off by default; the
existing pool path is simpler and good enough for breathing/static scenarios).

---

## 4  M/N Track Management (already implemented — tune parameters)

Current code uses `confirm_hits` and `max_misses`, which implements M/N management.
Recommended tuning for 20 Hz bags (walking scenario):

```python
TrackingConfig(
    confirm_hits=2,          # confirm after 2 hits (100 ms)
    init_hits=2,
    max_misses=max(10, int(0.25 * fps)),   # 250 ms coast
    velocity_decay=exp(-5.0 * dt_s),       # 200 ms time constant — already set
    gate_chi2=9.21,          # Mahalanobis gate (new field)
    vel_weight=0.0,          # keep 0 until range-Doppler CFAR is live
)
```

---

## 5  Parameter Reference

### `CfarDetectionConfig` (cfar.py)

| Field | Default | Notes |
|-------|---------|-------|
| `num_ref_cells` | 8 | reference cells per side |
| `num_guard_cells` | 2 | guard cells per side |
| `pfa` | 1e-2 | false alarm rate |
| `variant` | `"OS"` | use OS for multi-target; CA for single-target |
| `os_rank` | 12 | sorted index for OS (≈75th percentile of 16 cells) |
| `max_peaks_per_frame` | 4 | hard cap on detections per frame |

### `TrackingConfig` (types.py)

| Field | Default | Notes |
|-------|---------|-------|
| `sigma_meas_m` | 0.15 | range measurement noise (one tap ≈ 0.15 m) |
| `gate_distance_m` | 0.60 | pre-filter: reject if range gap > this |
| `gate_chi2` | 9.21 | chi² gate threshold (add this field) |
| `confirm_hits` | 2 | hits needed to confirm a track |
| `max_misses` | `int(0.25*fps)` | frames coasted before deletion |
| `velocity_decay` | `exp(-5*dt)` | prevents prediction drift during misses |
| `vel_weight` | 0.0 | enable after range-Doppler CFAR is live |

---

## 6  Development Order

1. Populate `range_rate_m_s` from the existing Doppler path more consistently so
   the tracker benefits from the new velocity-aware update on real bags.
2. Upgrade `cfar.py` to run OS-CFAR on the range-Doppler map and eliminate the
   separate doppler-animation FFT (consolidate).
3. Optionally add DBSCAN-based initiation if clutter still creates short-lived
   duplicate tentative tracks in crowded scenes.
4. Optionally promote to 2-D Cartesian EKF once `pair_rx_channels` + MVDR AoA is
   validated on the `two_person_fov` bag.
