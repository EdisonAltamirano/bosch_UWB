from __future__ import annotations

import numpy as np
from scipy.optimize import linear_sum_assignment

from .types import CfarDetection, Track, TrackingConfig


class MultiTargetTracker:
    """Constant-velocity Kalman filter tracker with nearest-neighbour gating.

    Lifecycle: Tentative → Confirmed (hit_count >= confirm_hits)
               Confirmed → Deleted  (miss_count >= max_misses)
               Tentative → Deleted  (not confirmed within init_window_frames)
    """

    def __init__(self, cfg: TrackingConfig) -> None:
        self.cfg = cfg
        self._tracks: list[Track] = []
        self._finished_confirmed_tracks: list[Track] = []
        self._next_id: int = 0
        # Each entry stores tentative detections until a track is promoted.
        self._pool: list[dict] = []

    # ------------------------------------------------------------------
    # State transition and noise matrices
    # ------------------------------------------------------------------

    def _F(self) -> np.ndarray:
        dt = self.cfg.dt_s
        return np.array([[1.0, dt], [0.0, 1.0]])

    def _Q(self) -> np.ndarray:
        dt = self.cfg.dt_s
        sr, sv = self.cfg.sigma_process_m, self.cfg.sigma_process_v
        return np.diag([sr ** 2 * dt, sv ** 2 * dt])

    _H = np.array([[1.0, 0.0]])   # measurement matrix (range only)

    def _measurement_prediction(self, state: np.ndarray) -> np.ndarray:
        if self.cfg.filter_name == "ekf":
            # Explicit nonlinear range-only observation model. With positive
            # 1D range states this is nearly identical to the linear Kalman
            # update, but it keeps the pipeline honest about the configured
            # filter mode and gives us an extensible EKF hook.
            return np.array([np.sqrt(state[0] ** 2 + 1e-12)], dtype=np.float64)
        return self._H @ state

    def _measurement_jacobian(self, state: np.ndarray) -> np.ndarray:
        if self.cfg.filter_name == "ekf":
            denom = float(np.sqrt(state[0] ** 2 + 1e-12))
            return np.array([[float(state[0]) / denom, 0.0]], dtype=np.float64)
        return self._H

    def _measurement_components(
        self,
        track: Track,
        det: CfarDetection,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        if det.range_rate_m_s is not None:
            z_meas = np.array([det.range_m, det.range_rate_m_s], dtype=np.float64)
            z_pred = np.array(track.state, dtype=np.float64)
            H = np.eye(2, dtype=np.float64)
            R = np.diag([self.cfg.sigma_meas_m ** 2, self.cfg.sigma_meas_v ** 2])
            return z_meas, z_pred, H, R

        H = self._measurement_jacobian(track.state)
        z_pred = self._measurement_prediction(track.state)
        z_meas = np.array([det.range_m], dtype=np.float64)
        R = np.array([[self.cfg.sigma_meas_m ** 2]], dtype=np.float64)
        return z_meas, z_pred, H, R

    def _assignment_cost(self, track: Track, det: CfarDetection) -> float:
        range_gap = abs(float(track.state[0]) - det.range_m)
        if range_gap > self.cfg.gate_distance_m:
            return np.inf

        z_meas, z_pred, H, R = self._measurement_components(track, det)
        innov = z_meas - z_pred
        S = H @ track.covariance @ H.T + R
        mah2 = float(innov.T @ np.linalg.solve(S, innov))
        if mah2 > self.cfg.gate_chi2:
            return np.inf
        return float(np.sqrt(mah2))

    def _initial_velocity(self, det: CfarDetection, entry: dict, timestamp_s: float) -> float:
        if det.range_rate_m_s is not None:
            return float(det.range_rate_m_s)

        prev_range = entry.get("prev_range")
        prev_ts = entry.get("prev_ts")
        if prev_range is None or prev_ts is None:
            prev_range = entry.get("start_range")
            prev_ts = entry.get("start_ts")
        if prev_range is None or prev_ts is None:
            return 0.0

        delta_t = float(timestamp_s) - float(prev_ts)
        if delta_t <= 0.0:
            return 0.0
        return float((det.range_m - float(prev_range)) / delta_t)

    def _append_observed_sample(self, track: Track, timestamp_s: float, range_m: float) -> None:
        track.history_t.append(timestamp_s)
        track.history_m.append(range_m)
        track.trajectory_t.append(timestamp_s)
        track.trajectory_m.append(range_m)
        track.trajectory_observed.append(True)

    def _append_predicted_sample(self, track: Track, timestamp_s: float) -> None:
        if track.trajectory_t and timestamp_s <= track.trajectory_t[-1]:
            return
        track.trajectory_t.append(timestamp_s)
        track.trajectory_m.append(float(track.state[0]))
        track.trajectory_observed.append(False)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def update(
        self,
        frame_idx: int,
        timestamp_s: float,
        detections: list[CfarDetection],
    ) -> list[Track]:
        """Process one frame. Returns all currently confirmed tracks."""
        F, Q = self._F(), self._Q()

        # 1. Predict
        for track in self._tracks:
            # Damp velocity toward zero during miss periods so a missed track stays near
            # its last known range instead of drifting at constant velocity indefinitely.
            if track.miss_count > 0 and self.cfg.velocity_decay < 1.0:
                track.state[1] *= self.cfg.velocity_decay
            track.state = F @ track.state
            track.covariance = F @ track.covariance @ F.T + Q

        # 2. Associate — Hungarian assignment (or greedy fallback) with gate
        assigned_tracks: set[int] = set()
        assigned_dets: set[int] = set()

        if self._tracks and detections:
            cost = np.full((len(self._tracks), len(detections)), np.inf)
            for ti, track in enumerate(self._tracks):
                for di, det in enumerate(detections):
                    cost[ti, di] = self._assignment_cost(track, det)

            if self.cfg.use_hungarian:
                # linear_sum_assignment cannot handle an all-inf matrix.
                # Replace inf with a large finite sentinel so the solver always
                # has a feasible problem; filter sentinel assignments out after.
                cost_finite = np.where(np.isinf(cost), 1e9, cost)
                row_ind, col_ind = linear_sum_assignment(cost_finite)
                pairs = [(int(ti), int(di)) for ti, di in zip(row_ind, col_ind)
                         if cost[ti, di] < np.inf]
            else:
                # Legacy greedy nearest-neighbour (kept for debugging comparison)
                cost_g = cost.copy()
                pairs = []
                while True:
                    flat = int(np.argmin(cost_g))
                    ti, di = flat // cost_g.shape[1], flat % cost_g.shape[1]
                    if cost_g[ti, di] == np.inf:
                        break
                    pairs.append((ti, di))
                    cost_g[ti, :] = np.inf
                    cost_g[:, di] = np.inf

            for ti, di in pairs:
                assigned_tracks.add(ti)
                assigned_dets.add(di)
                track = self._tracks[ti]
                z_meas, z_pred, H, R = self._measurement_components(track, detections[di])
                innov = z_meas - z_pred
                S = H @ track.covariance @ H.T + R
                K = track.covariance @ H.T @ np.linalg.inv(S)
                track.state = track.state + K @ innov
                track.covariance = (np.eye(2) - K @ H) @ track.covariance
                track.hit_count += 1
                track.miss_count = 0
                if track.hit_count >= self.cfg.confirm_hits:
                    track.confirmed = True
                self._append_observed_sample(track, timestamp_s, float(track.state[0]))

        # 3. Increment miss counter for unassigned tracks
        for ti, track in enumerate(self._tracks):
            if ti not in assigned_tracks:
                track.miss_count += 1
                if track.confirmed:
                    self._append_predicted_sample(track, timestamp_s)

        # 4. Tentative track initiation from unassigned detections
        for di, det in enumerate(detections):
            if di not in assigned_dets:
                self._try_init(det, frame_idx, timestamp_s)

        # 5. Delete tracks that exceeded the miss budget, but keep confirmed
        # tracks archived so end-of-session summaries still see them.
        surviving_tracks: list[Track] = []
        for track in self._tracks:
            if track.miss_count < self.cfg.max_misses:
                surviving_tracks.append(track)
            elif track.confirmed:
                self._finished_confirmed_tracks.append(track)
        self._tracks = surviving_tracks

        return [t for t in self._tracks if t.confirmed]

    def active_tracks_snapshot(self) -> list[Track]:
        return [t for t in self._tracks if t.confirmed]

    def tracks_snapshot(self, include_finished: bool = True) -> list[Track]:
        active_tracks = [t for t in self._tracks if t.confirmed]
        if not include_finished:
            return active_tracks
        return [*self._finished_confirmed_tracks, *active_tracks]

    # ------------------------------------------------------------------
    # Tentative track pool
    # ------------------------------------------------------------------

    def _try_init(self, det: CfarDetection, frame_idx: int, timestamp_s: float) -> None:
        cfg = self.cfg
        # Look for a nearby pool entry within the initiation window
        for entry in self._pool:
            age = frame_idx - entry["last_frame"]
            if age > cfg.init_window_frames:
                continue
            if abs(det.range_m - entry["last_range"]) <= cfg.gate_distance_m:
                entry["prev_range"] = entry["last_range"]
                entry["prev_ts"] = entry["last_ts"]
                entry["hits"] += 1
                entry["last_range"] = det.range_m
                entry["last_frame"] = frame_idx
                entry["last_ts"] = timestamp_s
                entry["history_ranges"].append(det.range_m)
                entry["history_ts"].append(timestamp_s)
                if entry["hits"] >= cfg.init_hits:
                    self._promote(det, entry, timestamp_s)
                return

        # No matching entry — start a new tentative entry
        self._pool.append({
            "hits": 1,
            "start_frame": frame_idx,
            "start_range": det.range_m,
            "start_ts": timestamp_s,
            "last_frame": frame_idx,
            "last_range": det.range_m,
            "last_ts": timestamp_s,
            "prev_range": None,
            "prev_ts": None,
            "history_ranges": [det.range_m],
            "history_ts": [timestamp_s],
        })
        # Prune stale pool entries
        self._pool = [
            e for e in self._pool
            if frame_idx - e["last_frame"] <= cfg.init_window_frames
        ]

    def _promote(self, det: CfarDetection, entry: dict, timestamp_s: float) -> None:
        initial_velocity = self._initial_velocity(det, entry, timestamp_s)
        track = Track(
            track_id=self._next_id,
            state=np.array([det.range_m, initial_velocity], dtype=np.float64),
            covariance=np.diag([self.cfg.sigma_meas_m ** 2, self.cfg.sigma_process_v ** 2]),
        )
        self._next_id += 1
        track.hit_count = entry["hits"]
        track.confirmed = track.hit_count >= self.cfg.confirm_hits
        for sample_t, sample_r in zip(entry["history_ts"], entry["history_ranges"]):
            self._append_observed_sample(track, float(sample_t), float(sample_r))
        self._tracks.append(track)
        self._pool.remove(entry)
